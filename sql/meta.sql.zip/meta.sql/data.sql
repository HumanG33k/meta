-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 03, 2014 at 04:28 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `meta`
--
CREATE DATABASE IF NOT EXISTS `meta` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `meta`;

--
-- Dumping data for table `categories`
--

REPLACE INTO `categories` (`id`, `name`, `description`, `position`, `created`, `updated`) VALUES
(1, 'communautÃ©', 'ici on parle de tout ce qui est rapport avec la communautÃ©', 1, '2014-11-29 00:00:00', '2014-11-30 18:47:49'),
(2, 'diverstissement', 'coin tranquil pour bavarder, parler de tout et de rien', 1, '2014-11-30 18:36:59', '2014-11-30 18:49:30');

--
-- Dumping data for table `forums`
--

REPLACE INTO `forums` (`id`, `position`, `nbpost`, `nbtread`, `category_id`, `state_id`, `created`, `updated`) VALUES
(1, 1, 1, 2, 2, 2, '2014-11-29 18:06:55', '2014-11-30 19:04:12'),
(2, 1, 0, 0, 1, 1, '2014-12-02 03:09:23', '2014-12-02 03:09:23');

--
-- Dumping data for table `groups`
--

REPLACE INTO `groups` (`id`, `name`, `constant`, `created`, `updated`) VALUES
(1, 'info3005', 1, '2014-11-26 18:31:45', '2014-11-26 18:31:45');

--
-- Dumping data for table `ips`
--

REPLACE INTO `ips` (`id`, `name`, `created`, `updated`) VALUES
(1, 2, '2014-11-30 00:00:00', '2014-11-30 00:00:00');

--
-- Dumping data for table `mimes`
--

REPLACE INTO `mimes` (`id`, `type_id`, `subtype_id`, `created`, `updated`) VALUES
(2, 4, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 4, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 4, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 4, 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 4, 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 4, 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 4, 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 4, 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 4, 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 4, 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 4, 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 4, 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 4, 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 4, 15, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 4, 16, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 4, 17, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 4, 18, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 4, 19, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 4, 20, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 4, 21, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 4, 22, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(23, 4, 23, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(24, 4, 24, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(25, 4, 25, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 4, 26, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, 4, 27, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(28, 4, 28, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(29, 4, 29, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(30, 4, 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(31, 4, 31, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(32, 4, 32, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(33, 4, 33, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 4, 34, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 4, 35, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(36, 4, 36, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, 4, 37, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, 4, 38, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, 4, 39, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(40, 4, 40, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(41, 4, 41, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

--
-- Dumping data for table `news`
--

REPLACE INTO `news` (`id`, `name`, `body`, `published`, `user_id`, `state_id`, `created`, `updated`) VALUES
(1, 'meta', 'j''ai le plaisir de vous annoncer le lancement de notre nouveau site meta, qui est un site communautaire !!', '2014-12-03 00:00:00', 2, 1, '2014-12-03 00:00:00', '2014-12-03 00:00:00');

--
-- Dumping data for table `posts`
--

REPLACE INTO `posts` (`id`, `name`, `email`, `user_id`, `thread_id`, `ip_id`, `created`, `updated`) VALUES
(1, 'Salut, quels sont vos films favoris', 'flegpin@hotmail.fr', 2, 1, 1, '2014-11-30 00:00:00', '2014-11-30 00:00:00');

--
-- Dumping data for table `states`
--

REPLACE INTO `states` (`id`, `name`, `description`) VALUES
(1, 'published', 'is published'),
(2, 'unpublished', 'statee');

--
-- Dumping data for table `subtypes`
--

REPLACE INTO `subtypes` (`id`, `name`, `created`, `updated`) VALUES
(1, 'cgm', NULL, NULL),
(2, 'example', NULL, NULL),
(3, 'fits', NULL, NULL),
(4, 'g3fax', NULL, NULL),
(5, 'jp2', NULL, NULL),
(6, 'jpm', NULL, NULL),
(7, 'jpx', NULL, NULL),
(8, 'naplps', NULL, NULL),
(9, 'png', NULL, NULL),
(10, 'prs.btif', NULL, NULL),
(11, 'prs.pti', NULL, NULL),
(12, 'pwg-raster', NULL, NULL),
(13, 't38', NULL, NULL),
(14, 'tiff', NULL, NULL),
(15, 'tiff-fx', NULL, NULL),
(16, 'vnd.adobe.photoshop', NULL, NULL),
(17, 'vnd.airzip.accelerator.azv', NULL, NULL),
(18, 'vnd.cns.inf2', NULL, NULL),
(19, 'vnd.dece.graphic', NULL, NULL),
(20, 'vnd-djvu', NULL, NULL),
(21, 'vnd.dwg', NULL, NULL),
(22, 'vnd.dxf', NULL, NULL),
(23, 'vnd.dvb.subtitle', NULL, NULL),
(24, 'vnd.fastbidsheet', NULL, NULL),
(25, 'vnd.fpx', NULL, NULL),
(26, 'vnd.fst', NULL, NULL),
(27, 'vnd.fujixerox.edmics-mmr', NULL, NULL),
(28, 'vnd.fujixerox.edmics-rlc', NULL, NULL),
(29, 'vnd.globalgraphics.pgb', NULL, NULL),
(30, 'vnd.microsoft.icon', NULL, NULL),
(31, 'vnd.mix', NULL, NULL),
(32, 'vnd.ms-modi', NULL, NULL),
(33, 'vnd.net-fpx', NULL, NULL),
(34, 'vnd.radiance', NULL, NULL),
(35, 'vnd.sealed-png', NULL, NULL),
(36, 'vnd.sealedmedia.softseal-gif', NULL, NULL),
(37, 'vnd.sealedmedia.softseal-jpg', NULL, NULL),
(38, 'vnd-svf', NULL, NULL),
(39, 'vnd.valve.source.texture', NULL, NULL),
(40, 'vnd-wap-wbmp', NULL, NULL),
(41, 'vnd.xiff', NULL, NULL);

--
-- Dumping data for table `threads`
--

REPLACE INTO `threads` (`id`, `name`, `statut`, `nbview`, `nbpost`, `nbcomment`, `created`, `updated`, `user_id`, `forum_id`) VALUES
(1, 'films', 1, 2, 3, 4, '2014-11-29 18:16:26', '2014-11-29 18:16:26', 1, 1),
(10, 'inception c''est de la bombe !', 0, 0, 0, 0, '2014-11-30 19:36:42', '2014-11-30 19:36:42', NULL, 1);

--
-- Dumping data for table `types`
--

REPLACE INTO `types` (`id`, `name`, `created`, `updated`) VALUES
(1, 'application', NULL, NULL),
(2, 'audio', NULL, NULL),
(3, 'example', NULL, NULL),
(4, 'image', NULL, NULL),
(5, 'message', NULL, NULL),
(6, 'model', NULL, NULL),
(7, 'multipart', NULL, NULL),
(8, 'text', NULL, NULL),
(9, 'video', NULL, NULL);

--
-- Dumping data for table `type_attributes`
--

REPLACE INTO `type_attributes` (`name`, `created`, `updated`, `id`) VALUES
('name', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
('name', '2014-11-26 00:00:00', '2014-11-26 00:00:00', 2);

--
-- Dumping data for table `users`
--

REPLACE INTO `users` (`id`, `username`, `password`, `name`, `firstname`, `lastname`, `birthday`, `biography`, `phone`, `email`, `website`, `avatar`, `gravavatar`, `isactive`, `sexe`, `created`, `updated`, `group_id`) VALUES
(1, 'aishaba', 'aishaba', '', 'aisha', 'bah', '2014-11-26', '', 2147483647, 'eab9005@umoncton.ca', '', '', 'aisha', 1, 0, '2014-11-26 18:33:19', '2014-11-26 18:34:13', 1),
(2, 'moh', 'hello', 'mohamed', '', 'berte', '2014-11-30', 'blablabla', 2147483647, 'flegpin@hotmail.fr', 'www.google.com', 'avatar', 'gravavatar', 1, 1, '2014-11-30 17:17:31', '2014-11-30 17:17:31', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
