-- phpMyAdmin SQL Dump
-- version 4.2.10.1deb1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Mar 25 Novembre 2014 à 17:01
-- Version du serveur :  10.0.14-MariaDB-2
-- Version de PHP :  5.6.2-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `meta`
--
CREATE DATABASE IF NOT EXISTS `meta` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `meta`;

-- --------------------------------------------------------

--
-- Structure de la table `attributes`
--

DROP TABLE IF EXISTS `attributes`;
CREATE TABLE IF NOT EXISTS `attributes` (
`id` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `type_attributes_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `attributes_elements`
--

DROP TABLE IF EXISTS `attributes_elements`;
CREATE TABLE IF NOT EXISTS `attributes_elements` (
  `id` int(11) NOT NULL,
  `name` int(11) NOT NULL COMMENT 'valeur d''un attribut ',
  `attribute_id` int(11) NOT NULL,
  `element_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `attributes_marks`
--

DROP TABLE IF EXISTS `attributes_marks`;
CREATE TABLE IF NOT EXISTS `attributes_marks` (
`id` int(11) NOT NULL,
  `mark_id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `description` varchar(50) NOT NULL,
  `position` int(2) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `categories_news`
--

DROP TABLE IF EXISTS `categories_news`;
CREATE TABLE IF NOT EXISTS `categories_news` (
`id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `new_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
`id` int(11) NOT NULL,
  `name` mediumtext COLLATE utf8_bin NOT NULL COMMENT 'content',
  `rank` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `new_id` int(11) DEFAULT NULL,
  `comment_id` int(11) DEFAULT NULL,
  `ip_id` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `contents`
--

DROP TABLE IF EXISTS `contents`;
CREATE TABLE IF NOT EXISTS `contents` (
`id` int(11) NOT NULL,
  `name` varchar(256) COLLATE utf8_bin NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `element_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `css_key_types`
--

DROP TABLE IF EXISTS `css_key_types`;
CREATE TABLE IF NOT EXISTS `css_key_types` (
`id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `description` varchar(256) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `css_types`
--

DROP TABLE IF EXISTS `css_types`;
CREATE TABLE IF NOT EXISTS `css_types` (
  `name` varchar(11) CHARACTER SET latin1 NOT NULL,
  `opening_syntax` varchar(11) CHARACTER SET latin1 NOT NULL,
`id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `elements`
--

DROP TABLE IF EXISTS `elements`;
CREATE TABLE IF NOT EXISTS `elements` (
  `id` int(11) NOT NULL,
  `mark_id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8_bin NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `position` int(11) NOT NULL,
  `description` varchar(250) COLLATE utf8_bin NOT NULL,
  `element_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `elements_keys`
--

DROP TABLE IF EXISTS `elements_keys`;
CREATE TABLE IF NOT EXISTS `elements_keys` (
  `id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8_bin NOT NULL,
  `element_id` int(11) NOT NULL,
  `key_id` int(11) NOT NULL,
  `css_key_type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `elements_pages`
--

DROP TABLE IF EXISTS `elements_pages`;
CREATE TABLE IF NOT EXISTS `elements_pages` (
`id` int(11) NOT NULL,
  `element_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `elements_pages_templates`
--

DROP TABLE IF EXISTS `elements_pages_templates`;
CREATE TABLE IF NOT EXISTS `elements_pages_templates` (
`id` int(11) NOT NULL,
  `element_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `template_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `elements_pseudo_elements_selectors`
--

DROP TABLE IF EXISTS `elements_pseudo_elements_selectors`;
CREATE TABLE IF NOT EXISTS `elements_pseudo_elements_selectors` (
`id` int(11) NOT NULL,
  `element_id` int(11) DEFAULT NULL,
  `pseudo_element_id` int(11) NOT NULL,
  `selector_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `entity`
--

DROP TABLE IF EXISTS `entity`;
CREATE TABLE IF NOT EXISTS `entity` (
  `name` varchar(11) NOT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  `syntax` varchar(20) NOT NULL,
`id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `extensions`
--

DROP TABLE IF EXISTS `extensions`;
CREATE TABLE IF NOT EXISTS `extensions` (
`id` int(11) NOT NULL,
  `name` varchar(10) COLLATE utf8_bin NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `extensions_mimes`
--

DROP TABLE IF EXISTS `extensions_mimes`;
CREATE TABLE IF NOT EXISTS `extensions_mimes` (
`id` int(11) NOT NULL,
  `extension_id` int(11) NOT NULL,
  `mime_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `forums`
--

DROP TABLE IF EXISTS `forums`;
CREATE TABLE IF NOT EXISTS `forums` (
`id` int(11) NOT NULL,
  `position` int(2) DEFAULT NULL,
  `nbpost` int(11) NOT NULL,
  `nbtread` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
`id` int(1) NOT NULL,
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `constant` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `html_types`
--

DROP TABLE IF EXISTS `html_types`;
CREATE TABLE IF NOT EXISTS `html_types` (
  `name` varchar(10) NOT NULL,
  `role` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
`id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ips`
--

DROP TABLE IF EXISTS `ips`;
CREATE TABLE IF NOT EXISTS `ips` (
`id` int(11) NOT NULL,
  `name` int(50) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `ips_users`
--

DROP TABLE IF EXISTS `ips_users`;
CREATE TABLE IF NOT EXISTS `ips_users` (
`id` int(11) NOT NULL,
  `ip_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` int(11) NOT NULL,
  `updated` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `keys`
--

DROP TABLE IF EXISTS `keys`;
CREATE TABLE IF NOT EXISTS `keys` (
`id` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `marks`
--

DROP TABLE IF EXISTS `marks`;
CREATE TABLE IF NOT EXISTS `marks` (
`id` int(11) NOT NULL,
  `name` varchar(11) CHARACTER SET latin1 NOT NULL,
  `opening_syntax` varchar(10) CHARACTER SET latin1 NOT NULL,
  `closing_syntax` varchar(10) CHARACTER SET latin1 NOT NULL,
  `html_type_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `media`
--

DROP TABLE IF EXISTS `media`;
CREATE TABLE IF NOT EXISTS `media` (
`id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `url` varchar(255) COLLATE utf8_bin NOT NULL,
  `used` int(5) NOT NULL DEFAULT '0',
  `mime_id` int(11) NOT NULL,
  `created` date NOT NULL,
  `updated` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `mimes`
--

DROP TABLE IF EXISTS `mimes`;
CREATE TABLE IF NOT EXISTS `mimes` (
`id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `subtype_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `mimes`
--

REPLACE INTO `mimes` (`id`, `type_id`, `subtype_id`, `created`, `updated`) VALUES
(2, 4, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 4, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 4, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 4, 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 4, 6, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 4, 7, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 4, 8, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 4, 9, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 4, 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 4, 11, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 4, 12, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 4, 13, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 4, 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 4, 15, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 4, 16, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 4, 17, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 4, 18, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 4, 19, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 4, 20, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 4, 21, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 4, 22, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(23, 4, 23, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(24, 4, 24, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(25, 4, 25, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 4, 26, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, 4, 27, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(28, 4, 28, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(29, 4, 29, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(30, 4, 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(31, 4, 31, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(32, 4, 32, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(33, 4, 33, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 4, 34, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 4, 35, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(36, 4, 36, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, 4, 37, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, 4, 38, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, 4, 39, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(40, 4, 40, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(41, 4, 41, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
`id` int(11) NOT NULL,
  `name` varchar(10) COLLATE utf8_bin NOT NULL,
  `body` longtext COLLATE utf8_bin NOT NULL,
  `published` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
`id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `adresse` int(250) NOT NULL,
  `state_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf8_bin NOT NULL COMMENT 'content',
  `email` varchar(250) COLLATE utf8_bin NOT NULL COMMENT 'poster email ',
  `user_id` int(11) DEFAULT NULL,
  `thread_id` int(11) NOT NULL,
  `ip_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `prefixes`
--

DROP TABLE IF EXISTS `prefixes`;
CREATE TABLE IF NOT EXISTS `prefixes` (
  `name` varchar(11) NOT NULL,
`id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `pseudo_elements`
--

DROP TABLE IF EXISTS `pseudo_elements`;
CREATE TABLE IF NOT EXISTS `pseudo_elements` (
`id` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `syntax` varchar(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  `prefixe_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `rules`
--

DROP TABLE IF EXISTS `rules`;
CREATE TABLE IF NOT EXISTS `rules` (
`id` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `prefixe_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `selectors`
--

DROP TABLE IF EXISTS `selectors`;
CREATE TABLE IF NOT EXISTS `selectors` (
`id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `css_type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `states`
--

DROP TABLE IF EXISTS `states`;
CREATE TABLE IF NOT EXISTS `states` (
`id` int(11) NOT NULL,
  `name` varchar(11) COLLATE utf8_bin NOT NULL,
  `description` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `subtypes`
--

DROP TABLE IF EXISTS `subtypes`;
CREATE TABLE IF NOT EXISTS `subtypes` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `subtypes`
--

REPLACE INTO `subtypes` (`id`, `name`, `created`, `updated`) VALUES
(1, 'cgm', NULL, NULL),
(2, 'example', NULL, NULL),
(3, 'fits', NULL, NULL),
(4, 'g3fax', NULL, NULL),
(5, 'jp2', NULL, NULL),
(6, 'jpm', NULL, NULL),
(7, 'jpx', NULL, NULL),
(8, 'naplps', NULL, NULL),
(9, 'png', NULL, NULL),
(10, 'prs.btif', NULL, NULL),
(11, 'prs.pti', NULL, NULL),
(12, 'pwg-raster', NULL, NULL),
(13, 't38', NULL, NULL),
(14, 'tiff', NULL, NULL),
(15, 'tiff-fx', NULL, NULL),
(16, 'vnd.adobe.photoshop', NULL, NULL),
(17, 'vnd.airzip.accelerator.azv', NULL, NULL),
(18, 'vnd.cns.inf2', NULL, NULL),
(19, 'vnd.dece.graphic', NULL, NULL),
(20, 'vnd-djvu', NULL, NULL),
(21, 'vnd.dwg', NULL, NULL),
(22, 'vnd.dxf', NULL, NULL),
(23, 'vnd.dvb.subtitle', NULL, NULL),
(24, 'vnd.fastbidsheet', NULL, NULL),
(25, 'vnd.fpx', NULL, NULL),
(26, 'vnd.fst', NULL, NULL),
(27, 'vnd.fujixerox.edmics-mmr', NULL, NULL),
(28, 'vnd.fujixerox.edmics-rlc', NULL, NULL),
(29, 'vnd.globalgraphics.pgb', NULL, NULL),
(30, 'vnd.microsoft.icon', NULL, NULL),
(31, 'vnd.mix', NULL, NULL),
(32, 'vnd.ms-modi', NULL, NULL),
(33, 'vnd.net-fpx', NULL, NULL),
(34, 'vnd.radiance', NULL, NULL),
(35, 'vnd.sealed-png', NULL, NULL),
(36, 'vnd.sealedmedia.softseal-gif', NULL, NULL),
(37, 'vnd.sealedmedia.softseal-jpg', NULL, NULL),
(38, 'vnd-svf', NULL, NULL),
(39, 'vnd.valve.source.texture', NULL, NULL),
(40, 'vnd-wap-wbmp', NULL, NULL),
(41, 'vnd.xiff', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `templates`
--

DROP TABLE IF EXISTS `templates`;
CREATE TABLE IF NOT EXISTS `templates` (
`id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `version` varchar(10) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `threads`
--

DROP TABLE IF EXISTS `threads`;
CREATE TABLE IF NOT EXISTS `threads` (
`id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_bin NOT NULL,
  `statut` tinyint(1) NOT NULL,
  `nbview` int(11) NOT NULL,
  `nbpost` int(11) NOT NULL,
  `nbcomment` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `forum_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `types`
--

DROP TABLE IF EXISTS `types`;
CREATE TABLE IF NOT EXISTS `types` (
`id` int(11) NOT NULL,
  `name` varchar(25) COLLATE utf8_bin NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `types`
--

REPLACE INTO `types` (`id`, `name`, `created`, `updated`) VALUES
(1, 'application', NULL, NULL),
(2, 'audio', NULL, NULL),
(3, 'example', NULL, NULL),
(4, 'image', NULL, NULL),
(5, 'message', NULL, NULL),
(6, 'model', NULL, NULL),
(7, 'multipart', NULL, NULL),
(8, 'text', NULL, NULL),
(9, 'video', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `type_attributes`
--

DROP TABLE IF EXISTS `type_attributes`;
CREATE TABLE IF NOT EXISTS `type_attributes` (
  `name` varchar(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
`id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_bin NOT NULL,
  `password` varchar(50) COLLATE utf8_bin NOT NULL,
  `name` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `firstname` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `lastname` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `biography` mediumtext COLLATE utf8_bin,
  `phone` int(20) DEFAULT NULL,
  `email` varchar(70) COLLATE utf8_bin NOT NULL,
  `website` varchar(70) COLLATE utf8_bin DEFAULT NULL,
  `avatar` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `gravavatar` varchar(100) COLLATE utf8_bin NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '1',
  `sexe` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `attributes`
--
ALTER TABLE `attributes`
 ADD PRIMARY KEY (`id`), ADD KEY `type_attributes` (`type_attributes_id`);

--
-- Index pour la table `attributes_elements`
--
ALTER TABLE `attributes_elements`
 ADD PRIMARY KEY (`id`), ADD KEY `attribute_id` (`attribute_id`,`element_id`), ADD KEY `element_id` (`element_id`);

--
-- Index pour la table `attributes_marks`
--
ALTER TABLE `attributes_marks`
 ADD PRIMARY KEY (`id`), ADD KEY `mark_id` (`mark_id`), ADD KEY `attribute_id` (`attribute_id`);

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`id`), ADD KEY `categorie_id` (`id`);

--
-- Index pour la table `categories_news`
--
ALTER TABLE `categories_news`
 ADD PRIMARY KEY (`id`), ADD KEY `category_id` (`category_id`), ADD KEY `new_id` (`new_id`);

--
-- Index pour la table `comments`
--
ALTER TABLE `comments`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`,`comment_id`,`ip_id`), ADD KEY `comment_id` (`comment_id`), ADD KEY `ip_id` (`ip_id`), ADD KEY `new_id` (`new_id`), ADD KEY `new_id_2` (`new_id`);

--
-- Index pour la table `contents`
--
ALTER TABLE `contents`
 ADD PRIMARY KEY (`id`), ADD KEY `element_id` (`element_id`);

--
-- Index pour la table `css_key_types`
--
ALTER TABLE `css_key_types`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `css_types`
--
ALTER TABLE `css_types`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `elements`
--
ALTER TABLE `elements`
 ADD PRIMARY KEY (`id`), ADD KEY `mark_id` (`mark_id`,`content_id`), ADD KEY `content_id` (`content_id`), ADD KEY `mark_id_2` (`mark_id`,`content_id`), ADD KEY `element_id` (`element_id`);

--
-- Index pour la table `elements_keys`
--
ALTER TABLE `elements_keys`
 ADD PRIMARY KEY (`id`), ADD KEY `element_id` (`element_id`), ADD KEY `key_id` (`key_id`), ADD KEY `css_type_value_id` (`css_key_type_id`);

--
-- Index pour la table `elements_pages`
--
ALTER TABLE `elements_pages`
 ADD PRIMARY KEY (`id`), ADD KEY `element_id` (`element_id`,`page_id`), ADD KEY `page_id` (`page_id`);

--
-- Index pour la table `elements_pages_templates`
--
ALTER TABLE `elements_pages_templates`
 ADD PRIMARY KEY (`id`), ADD KEY `element_id` (`element_id`), ADD KEY `page_id` (`page_id`), ADD KEY `template_id` (`template_id`);

--
-- Index pour la table `elements_pseudo_elements_selectors`
--
ALTER TABLE `elements_pseudo_elements_selectors`
 ADD PRIMARY KEY (`id`), ADD KEY `element_id` (`element_id`), ADD KEY `pseudo_element_id` (`pseudo_element_id`), ADD KEY `selector_id` (`selector_id`);

--
-- Index pour la table `entity`
--
ALTER TABLE `entity`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `extensions`
--
ALTER TABLE `extensions`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `extensions_mimes`
--
ALTER TABLE `extensions_mimes`
 ADD PRIMARY KEY (`id`), ADD KEY `extension_id` (`extension_id`,`mime_id`), ADD KEY `mine_id` (`mime_id`);

--
-- Index pour la table `forums`
--
ALTER TABLE `forums`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `state_id` (`state_id`), ADD KEY `categorie_id` (`category_id`), ADD KEY `category_id` (`category_id`);

--
-- Index pour la table `groups`
--
ALTER TABLE `groups`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `html_types`
--
ALTER TABLE `html_types`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `ips`
--
ALTER TABLE `ips`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `ips_users`
--
ALTER TABLE `ips_users`
 ADD PRIMARY KEY (`id`), ADD KEY `ip_id` (`ip_id`,`user_id`), ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `keys`
--
ALTER TABLE `keys`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `marks`
--
ALTER TABLE `marks`
 ADD PRIMARY KEY (`id`), ADD KEY `html_type_id` (`html_type_id`);

--
-- Index pour la table `media`
--
ALTER TABLE `media`
 ADD PRIMARY KEY (`id`), ADD KEY `type_id` (`mime_id`);

--
-- Index pour la table `mimes`
--
ALTER TABLE `mimes`
 ADD PRIMARY KEY (`id`), ADD KEY `type_id` (`type_id`,`subtype_id`), ADD KEY `subtype_id` (`subtype_id`);

--
-- Index pour la table `news`
--
ALTER TABLE `news`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`), ADD KEY `state_id` (`state_id`), ADD KEY `user_id_2` (`user_id`);

--
-- Index pour la table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id`), ADD KEY `state_id` (`state_id`);

--
-- Index pour la table `posts`
--
ALTER TABLE `posts`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`), ADD KEY `tread_id` (`thread_id`), ADD KEY `ip_id` (`ip_id`);

--
-- Index pour la table `prefixes`
--
ALTER TABLE `prefixes`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pseudo_elements`
--
ALTER TABLE `pseudo_elements`
 ADD PRIMARY KEY (`id`), ADD KEY `prefixe_id` (`prefixe_id`);

--
-- Index pour la table `rules`
--
ALTER TABLE `rules`
 ADD PRIMARY KEY (`id`), ADD KEY `prefixe_id` (`prefixe_id`);

--
-- Index pour la table `selectors`
--
ALTER TABLE `selectors`
 ADD PRIMARY KEY (`id`), ADD KEY `type__css_id` (`css_type_id`);

--
-- Index pour la table `states`
--
ALTER TABLE `states`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `subtypes`
--
ALTER TABLE `subtypes`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `templates`
--
ALTER TABLE `templates`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `threads`
--
ALTER TABLE `threads`
 ADD PRIMARY KEY (`id`), ADD KEY `forum_id` (`forum_id`), ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `types`
--
ALTER TABLE `types`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `type_attributes`
--
ALTER TABLE `type_attributes`
 ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `publicname` (`name`), ADD UNIQUE KEY `username` (`username`,`name`), ADD KEY `group_id` (`group_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `attributes`
--
ALTER TABLE `attributes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `attributes_marks`
--
ALTER TABLE `attributes_marks`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `categories_news`
--
ALTER TABLE `categories_news`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `comments`
--
ALTER TABLE `comments`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `contents`
--
ALTER TABLE `contents`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `css_key_types`
--
ALTER TABLE `css_key_types`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `css_types`
--
ALTER TABLE `css_types`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `elements_pages`
--
ALTER TABLE `elements_pages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `elements_pages_templates`
--
ALTER TABLE `elements_pages_templates`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `elements_pseudo_elements_selectors`
--
ALTER TABLE `elements_pseudo_elements_selectors`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `entity`
--
ALTER TABLE `entity`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `extensions`
--
ALTER TABLE `extensions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `extensions_mimes`
--
ALTER TABLE `extensions_mimes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `forums`
--
ALTER TABLE `forums`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `groups`
--
ALTER TABLE `groups`
MODIFY `id` int(1) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `html_types`
--
ALTER TABLE `html_types`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ips`
--
ALTER TABLE `ips`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ips_users`
--
ALTER TABLE `ips_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `keys`
--
ALTER TABLE `keys`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `marks`
--
ALTER TABLE `marks`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `media`
--
ALTER TABLE `media`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `mimes`
--
ALTER TABLE `mimes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT pour la table `news`
--
ALTER TABLE `news`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `pages`
--
ALTER TABLE `pages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `posts`
--
ALTER TABLE `posts`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `prefixes`
--
ALTER TABLE `prefixes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `pseudo_elements`
--
ALTER TABLE `pseudo_elements`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `rules`
--
ALTER TABLE `rules`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `selectors`
--
ALTER TABLE `selectors`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `states`
--
ALTER TABLE `states`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `subtypes`
--
ALTER TABLE `subtypes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT pour la table `templates`
--
ALTER TABLE `templates`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `threads`
--
ALTER TABLE `threads`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `types`
--
ALTER TABLE `types`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `type_attributes`
--
ALTER TABLE `type_attributes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `attributes`
--
ALTER TABLE `attributes`
ADD CONSTRAINT `attributes_ibfk_1` FOREIGN KEY (`type_attributes_id`) REFERENCES `type_attributes` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `attributes_elements`
--
ALTER TABLE `attributes_elements`
ADD CONSTRAINT `attributes_elements_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `attributes_elements_ibfk_2` FOREIGN KEY (`element_id`) REFERENCES `elements` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `attributes_marks`
--
ALTER TABLE `attributes_marks`
ADD CONSTRAINT `attributes_marks_ibfk_1` FOREIGN KEY (`mark_id`) REFERENCES `marks` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `attributes_marks_ibfk_2` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `categories_news`
--
ALTER TABLE `categories_news`
ADD CONSTRAINT `categories_news_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `categories_news_ibfk_2` FOREIGN KEY (`new_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `comments`
--
ALTER TABLE `comments`
ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`ip_id`) REFERENCES `ips` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
ADD CONSTRAINT `comments_ibfk_4` FOREIGN KEY (`new_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `contents`
--
ALTER TABLE `contents`
ADD CONSTRAINT `contents_ibfk_1` FOREIGN KEY (`element_id`) REFERENCES `elements` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `elements`
--
ALTER TABLE `elements`
ADD CONSTRAINT `elements_ibfk_1` FOREIGN KEY (`mark_id`) REFERENCES `marks` (`id`),
ADD CONSTRAINT `elements_ibfk_2` FOREIGN KEY (`element_id`) REFERENCES `elements` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `elements_keys`
--
ALTER TABLE `elements_keys`
ADD CONSTRAINT `elements_keys_ibfk_1` FOREIGN KEY (`element_id`) REFERENCES `elements` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `elements_keys_ibfk_2` FOREIGN KEY (`key_id`) REFERENCES `keys` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `elements_keys_ibfk_3` FOREIGN KEY (`css_key_type_id`) REFERENCES `css_key_types` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `elements_pages`
--
ALTER TABLE `elements_pages`
ADD CONSTRAINT `elements_pages_ibfk_1` FOREIGN KEY (`element_id`) REFERENCES `elements` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `elements_pages_ibfk_2` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `elements_pages_templates`
--
ALTER TABLE `elements_pages_templates`
ADD CONSTRAINT `elements_pages_templates_ibfk_1` FOREIGN KEY (`element_id`) REFERENCES `elements` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `elements_pages_templates_ibfk_2` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `elements_pages_templates_ibfk_3` FOREIGN KEY (`template_id`) REFERENCES `templates` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `elements_pseudo_elements_selectors`
--
ALTER TABLE `elements_pseudo_elements_selectors`
ADD CONSTRAINT `elements_pseudo_elements_selectors_ibfk_1` FOREIGN KEY (`element_id`) REFERENCES `elements` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `elements_pseudo_elements_selectors_ibfk_2` FOREIGN KEY (`pseudo_element_id`) REFERENCES `pseudo_elements` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `elements_pseudo_elements_selectors_ibfk_3` FOREIGN KEY (`selector_id`) REFERENCES `selectors` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `extensions_mimes`
--
ALTER TABLE `extensions_mimes`
ADD CONSTRAINT `extensions_mimes_ibfk_1` FOREIGN KEY (`extension_id`) REFERENCES `extensions` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `extensions_mimes_ibfk_2` FOREIGN KEY (`mime_id`) REFERENCES `mimes` (`id`);

--
-- Contraintes pour la table `forums`
--
ALTER TABLE `forums`
ADD CONSTRAINT `forums_ibfk_2` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `forums_ibfk_3` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `ips_users`
--
ALTER TABLE `ips_users`
ADD CONSTRAINT `ips_users_ibfk_1` FOREIGN KEY (`ip_id`) REFERENCES `ips` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `ips_users_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `marks`
--
ALTER TABLE `marks`
ADD CONSTRAINT `marks_ibfk_1` FOREIGN KEY (`html_type_id`) REFERENCES `html_types` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `media`
--
ALTER TABLE `media`
ADD CONSTRAINT `media_ibfk_1` FOREIGN KEY (`mime_id`) REFERENCES `mimes` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `mimes`
--
ALTER TABLE `mimes`
ADD CONSTRAINT `mimes_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `mimes_ibfk_2` FOREIGN KEY (`subtype_id`) REFERENCES `subtypes` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `news`
--
ALTER TABLE `news`
ADD CONSTRAINT `news_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `news_ibfk_3` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `posts`
--
ALTER TABLE `posts`
ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
ADD CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`thread_id`) REFERENCES `threads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `posts_ibfk_3` FOREIGN KEY (`ip_id`) REFERENCES `ips` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `pseudo_elements`
--
ALTER TABLE `pseudo_elements`
ADD CONSTRAINT `pseudo_elements_ibfk_1` FOREIGN KEY (`prefixe_id`) REFERENCES `prefixes` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `rules`
--
ALTER TABLE `rules`
ADD CONSTRAINT `rules_ibfk_1` FOREIGN KEY (`prefixe_id`) REFERENCES `prefixes` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `selectors`
--
ALTER TABLE `selectors`
ADD CONSTRAINT `selectors_ibfk_1` FOREIGN KEY (`css_type_id`) REFERENCES `css_types` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `threads`
--
ALTER TABLE `threads`
ADD CONSTRAINT `threads_ibfk_1` FOREIGN KEY (`forum_id`) REFERENCES `forums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `threads_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `users`
--
ALTER TABLE `users`
ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
